import React from "react";

const SingleJournal = () => {
  return <div>SingleJournal</div>;
};

export default SingleJournal;
